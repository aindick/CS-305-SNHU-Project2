package com.snhu.sslserver;
import java.security.MessageDigest;

/*
 * Alexis Indick
 * CS 305: Software Security
 * Project 2
 * 10/16/22
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
/*
 * Alexis Indick
 * CS305: Software Security
 * Project 2
 * 10/16/22
 */
@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{   
    @GetMapping("/hash") // This maps the "/hash" keyword to the server.
    public String nameGreeting(@RequestParam(value= "inputString", defaultValue = "Hello World Check Sum!")String inputData)throws Exception {
    	return myHash(inputData);
    }
    //Using SHA-256 algorithm and throws an exception if there is an issue with the hash.
    public String myHash(String data) throws Exception{
    	MessageDigest messageD = MessageDigest.getInstance("SHA-256");
    	messageD.update(data.getBytes());
    	
    	// The message digest needs to be in bytes.
    	byte[] digest = messageD.digest();
    	
    	// Converting the byte array into a hex string. 
        StringBuffer hexString = new StringBuffer();
        
        for (int i = 0;i < digest.length;i++) {
           hexString.append(Integer.toHexString(0xFF & digest[i]));
        }
        //String for my name
        String name = "Name: ";
        name += "Alexis Indick <p> ";
        
        //String for the checksum data value of 256 characters.
        String returnS = "data:" + " " + String.format(data) ;
        returnS += "<p> SHA-265: CheckSum Value: ";
    	        
        return name + returnS + hexString;
    }
}
